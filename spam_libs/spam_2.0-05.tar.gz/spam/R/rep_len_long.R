rep_len_long <- function(x, length.out, NAOK = getOption("spam.NAOK")){
    if(length.out <= 2147483647)
        return(rep_len(x = x, length.out = length.out))
    .C64("rep_len_long",
         SIGNATURE = c("double", "int64", "int64", "double"),

         x = x,
         lx = length(x),
         length = length.out,
         out = numeric_dc(length.out),

         INTENT = c("r","r","r","w"),
         NAOK = NAOK, 
         )$out
}
